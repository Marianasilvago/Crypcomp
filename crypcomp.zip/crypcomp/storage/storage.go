package storage

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"start/crypcomp/models"
	"strings"
	"time"
)

type CryptoSQLStorage struct {
	conn *sql.Conn
}

func NewCryptoSQLStorage(conn *sql.Conn) *CryptoSQLStorage {
	return &CryptoSQLStorage{conn: conn}
}

func (s *CryptoSQLStorage) CreateCurr(ctx context.Context, curr models.Currency, display models.CurrencyDisplay, batchID int64) error {
	tx, err := s.conn.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()

	queryCurrInsert := "insert into currency " +
		"(created_at, curr_from, curr_to, change_24_hour, change_pct_24_hour, open_24_hour, volume_24_hour, volume_24_hour_to, low_24_hour, high_24_hour, price, supply, mkt_cap, batch_id) " +
		"values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?); "

	queryDisplayInset := "insert into currency_display " +
		"(change_24_hour, change_pct_24_hour, open_24_hour, volume_24_hour, volume_24_hour_to, low_24_hour, high_24_hour, price, supply, mkt_cap, currency_id) " +
		"values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);"

	curr.CreatedAt = time.Now().UTC().Unix()
	r, err := tx.ExecContext(ctx, queryCurrInsert,
		curr.CreatedAt, curr.CurrFrom, curr.CurrTo, curr.Change24Hour, curr.ChangePCT24Hour, curr.Open24Hour,
		curr.Volume24Hour, curr.Volume24HourTo, curr.Low24Hour, curr.High24Hour, curr.Price, curr.Supply, curr.MKTCAP, batchID)
	if err != nil {
		return err
	}
	currId, err := r.LastInsertId()
	if err != nil {
		return err
	}
	_, err = tx.ExecContext(ctx, queryDisplayInset,
		display.ChangePCT24Hour, display.ChangePCT24Hour, display.Open24Hour, display.Volume24Hour, display.Volume24HourTo,
		display.Low24Hour, display.High24Hour, display.Price, display.Supply, display.MKTCAP, currId)
	if err != nil {
		return err
	}
	tx.Commit()
	return nil
}

func (s *CryptoSQLStorage) GetLatestCurr(ctx context.Context, fsym []string, tsym []string) ([]models.CurrencyCompare, error) {
	tx, err := s.conn.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()

	batchID, err := s.getLatestBatchID(ctx, tx)
	if err != nil {
		return nil, err
	}

	var currencyCompares []models.CurrencyCompare

	fstring := "'" + strings.Join(fsym, "', '") + "'"
	tstring := "'" + strings.Join(tsym, "', '") + "'"
	query := fmt.Sprintf("select c.id, c.curr_from, c.curr_to, c.change_24_hour, c.change_pct_24_hour, c.open_24_hour, c.volume_24_hour, c.volume_24_hour_to, c.low_24_hour, c.high_24_hour, c.price, c.supply, c.mkt_cap, cd.change_24_hour, cd.change_pct_24_hour, cd.open_24_hour, cd.volume_24_hour, cd.volume_24_hour_to, cd.low_24_hour, cd.high_24_hour, cd.price, cd.supply, cd.mkt_cap, cd.currency_id from currency c join currency_display cd on c.id = cd.currency_id where curr_from in (%v) and curr_to in (%v) and batch_id = ?;", fstring, tstring)
	rows, err := tx.QueryContext(ctx, query, batchID)
	if err != nil {
		return nil, err
	}

	for rows.Next() {
		var curr models.Currency
		var display models.CurrencyDisplay

		err = rows.Scan(&curr.ID, &curr.CurrFrom, &curr.CurrTo, &curr.Change24Hour, &curr.ChangePCT24Hour, &curr.Open24Hour, &curr.Volume24Hour, &curr.Volume24HourTo,
			&curr.Low24Hour, &curr.High24Hour, &curr.Price, &curr.Supply, &curr.MKTCAP, &display.Change24Hour,
			&display.ChangePCT24Hour, &display.Open24Hour, &display.Volume24Hour, &display.Volume24HourTo, &display.Low24Hour,
			&display.High24Hour, &display.Price, &display.Supply, &display.MKTCAP, &display.CurrencyID)
		if err != nil {
			return nil, err
		}

		c := models.CurrencyCompare{
			From:    curr.CurrFrom,
			To:      curr.CurrTo,
			Raw:     curr,
			Display: display,
		}
		currencyCompares = append(currencyCompares, c)
	}
	tx.Commit()
	log.Println("Successfully fetched latest currency compare date from DB")
	return currencyCompares, nil
}

func (s *CryptoSQLStorage) GetLatestBatch(ctx context.Context) (int64, error) {
	tx, err := s.conn.BeginTx(ctx, nil)
	if err != nil {
		return 0, err
	}
	defer tx.Rollback()

	batchID, err := s.getLatestBatchID(ctx, tx)
	if err != nil {
		return 0, err
	}
	log.Println("Successfully fetched latest batch ID from DB")
	return batchID, nil
}

func (s *CryptoSQLStorage) getLatestBatchID(ctx context.Context, tx *sql.Tx) (int64, error) {
	query := "select batch_id from currency order by created_at desc limit 1"
	row := tx.QueryRowContext(ctx, query)

	var batchID int64
	err := row.Scan(&batchID)
	if err != nil {
		return 0, err
	}
	return batchID, nil
}
