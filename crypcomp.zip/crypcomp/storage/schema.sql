CREATE DATABASE IF NOT EXISTS crypto;

create table currency (
                          id bigint AUTO_INCREMENT PRIMARY KEY,
                          created_at bigint not null,
                          curr_from varchar(10),
                          curr_to varchar(10),
                          change_24_hour decimal(65,20),
                          change_pct_24_hour decimal(65,20),
                          open_24_hour decimal(65,20),
                          volume_24_hour decimal(65,20),
                          volume_24_hour_to decimal(65,20),
                          low_24_hour decimal(65,20),
                          high_24_hour decimal(65,20),
                          price decimal(65,20),
                          supply decimal(65,20),
                          mkt_cap decimal(65,20),
                          batch_id bigint
);

create table currency_display (
                                  id bigint AUTO_INCREMENT PRIMARY KEY,
                                  change_24_hour varchar(255),
                                  change_pct_24_hour varchar(255),
                                  open_24_hour varchar(255),
                                  volume_24_hour varchar(255),
                                  volume_24_hour_to varchar(255),
                                  low_24_hour varchar(255),
                                  high_24_hour varchar(255),
                                  price varchar(255),
                                  supply varchar(255),
                                  mkt_cap varchar(255),
                                  currency_id bigint,
                                  foreign key (currency_id) references currency(id)
);