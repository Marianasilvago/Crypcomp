package app

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"start/crypcomp/api"
	"start/crypcomp/api/handlers"
	"start/crypcomp/client"
	"start/crypcomp/config"
	"start/crypcomp/fetcher"
	"start/crypcomp/storage"
	"time"
)

type App struct {
	server              *api.Server
	cfg                 *config.Config
	storage             *storage.CryptoSQLStorage
	cryptoCompareClient *client.CryptoCompareClient
	fetch               *fetcher.Fetch
	ctx                 context.Context
}

func NewApp() *App {
	a := App{}
	a.ctx = context.Background()

	a.configProvider().
		storageProvider(a.ctx).
		cryptoCompareClientProvider().
		fetcherProvider().
		serverProvider()

	return &a
}

func (a *App) Start() {
	go a.fetch.Run(a.ctx)
	a.server.Start()
}

func (a *App) Stop() {
	a.server.Shutdown(a.ctx)
}

func (a *App) configProvider() *App {
	cfg, err := config.NewConfig("settings.yaml")
	if err != nil {
		log.Fatal(err)
	}
	a.cfg = cfg
	return a
}

func (a *App) storageProvider(ctx context.Context) *App {
	connString := fmt.Sprintf("%v:%v@tcp(%v:%v)/crypto", a.cfg.MySQLUser, a.cfg.MySQLPwd, a.cfg.MySQLHost, a.cfg.MySQLPort)
	// Waiting database initialization
	time.Sleep(time.Second*10)
	db, err := sql.Open("mysql", connString)
	if err != nil {
		log.Fatal(err)
	}
	conn, err := db.Conn(ctx)
	if err != nil {
		log.Fatal(err)
	}
	s := storage.NewCryptoSQLStorage(conn)
	a.storage = s
	return a
}

func (a *App) cryptoCompareClientProvider() *App {
	c := client.NewCryptoCompareClient()
	a.cryptoCompareClient = c
	return a
}

func (a *App) fetcherProvider() *App {
	f := fetcher.NewFetch(a.cryptoCompareClient, a.storage, a.cfg)
	a.fetch = f
	return a
}

func (a *App) serverProvider() *App {
	h := handlers.NewCompareHandler(a.storage, a.cfg)
	s := api.NewServer(":8080", h)
	a.server = s
	return a
}
