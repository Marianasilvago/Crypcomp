## TODO
1. SQL Database it's not is the best way to store data which often update. Possible to use key-value storage or MongoDB to more performance.
1. Enhance logging. User zap or zerolog
1. Find lib for MySQL with optimized batch update functionality. Like pgx|pgxpool for Postgres.
1. Fix SQL query to avoid security issue

## Quick Start
1. `docker-compose up`
1. Create tables to DB from storage/schema.sql if init script didn't do it.
