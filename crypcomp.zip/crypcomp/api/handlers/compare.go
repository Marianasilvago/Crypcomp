package handlers

import (
	"context"
	"github.com/gin-gonic/gin"
	"log"
	"net/http"
	"start/crypcomp/config"
	"start/crypcomp/models"
	"strings"
)

type Storage interface {
	GetLatestCurr(ctx context.Context, fsyms []string, tsyms []string) ([]models.CurrencyCompare, error)
}

type CompareHandler struct {
	storage Storage
	cfg     *config.Config
}

func NewCompareHandler(storage Storage, cfg *config.Config) *CompareHandler {
	return &CompareHandler{
		storage: storage,
		cfg:     cfg,
	}
}

type CurrCompareQuery struct {
	Fsyms string `form:"fsyms" binding:"required"`
	Tsyms string `form:"tsyms" binding:"required"`
}

func (h *CompareHandler) GetCurrCompare(c *gin.Context) {
	var query CurrCompareQuery
	err := c.BindQuery(&query)
	if err != nil {
		log.Println(err)
		c.Status(http.StatusBadRequest)
		return
	}
	resp, err := h.storage.GetLatestCurr(c, strings.Split(query.Fsyms, ","), strings.Split(query.Tsyms, ","))
	if err != nil {
		log.Println(err)
		c.Status(http.StatusInternalServerError)
		return
	}

	c.JSON(http.StatusOK, resp)
}

func (h *CompareHandler) BindRoutes(router *gin.Engine) {
	router.GET("/price", h.GetCurrCompare)
}
