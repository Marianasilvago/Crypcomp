package api

import (
	"context"
	"errors"
	"github.com/gin-gonic/gin"
	"log"
	"net/http"
	"time"
)

const shutdownTimeout = 5 * time.Second

type Server struct {
	server *http.Server
}

func NewServer(port string, routes ...RouteBinder) *Server {
	gin.SetMode(gin.ReleaseMode)

	return &Server{
		server: &http.Server{
			Addr:    port,
			Handler: newRouterBuilder(routes).addMiddleware().addRoutes().build(),
		}}
}

func (s *Server) Start() {
	go func() {
		log.Println("Starting server on " + s.server.Addr)
		if err := s.server.ListenAndServe(); err != nil && errors.Is(err, http.ErrServerClosed) {
			log.Fatal("Serving server failed")
		}
	}()
}

func (s *Server) Shutdown(ctx context.Context) {
	ctx, cancel := context.WithTimeout(ctx, shutdownTimeout)
	defer cancel()
	s.server.SetKeepAlivesEnabled(false)
	_ = s.server.Shutdown(ctx)
	log.Println("Server stopped")
}
