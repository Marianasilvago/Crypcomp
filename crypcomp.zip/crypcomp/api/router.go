package api

import (
	"os"

	"go.uber.org/zap/zapcore"

	"github.com/gin-gonic/gin"
	cors "github.com/rs/cors/wrapper/gin"
)

type RouteBinder interface {
	BindRoutes(engine *gin.Engine)
}

type routerBuilder struct {
	router *gin.Engine
	routes []RouteBinder
}

func newRouterBuilder(routes []RouteBinder) *routerBuilder {
	return &routerBuilder{
		router: gin.New(),
		routes: routes,
	}
}

func (b *routerBuilder) addMiddleware() *routerBuilder {
	b.router.Use(gin.RecoveryWithWriter(zapcore.AddSync(os.Stdout)))
	b.router.Use(cors.Default())
	b.router.Use(defaultHeaders())
	return b
}

func (b *routerBuilder) addRoutes() *routerBuilder {
	for _, r := range b.routes {
		r.BindRoutes(b.router)
	}
	return b
}

func (b *routerBuilder) build() *gin.Engine {
	return b.router
}

func defaultHeaders() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Header("content-type", "application/json")
		c.Next()
	}
}
