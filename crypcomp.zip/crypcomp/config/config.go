package config

import (
	"github.com/caarlos0/env"
	"gopkg.in/yaml.v2"
	"io/ioutil"
	"log"
)

type Сurrencies struct {
	Fsyms []string `yaml:"fsyms"`
	Tsyms []string `yaml:"tsyms"`
}

type yamlSettings struct {
	Currencies Сurrencies `yaml:"currencies"`
}

type Config struct {
	YamlSettings yamlSettings
	MySQLUser    string `env:"TEST_MYSQL_USER,required"`
	MySQLPwd     string `env:"TEST_MYSQL_PASSWORD,required"`
	MySQLHost    string `env:"TEST_MYSQL_HOST,required"`
	MySQLPort    string `env:"TEST_MYSQL_PORT,required"`
}

func NewConfig(pathYaml string) (*Config, error) {
	var c Config
	err := c.parseYaml(pathYaml)
	if err != nil {
		return nil, err
	}
	if err := c.getEnvs(); err != nil {
		return nil, err
	}
	return &c, nil
}

func (c *Config) parseYaml(path string) error {
	var settings yamlSettings
	data, err := ioutil.ReadFile(path)
	if err != nil {
		return err
	}
	if err := yaml.Unmarshal(data, &settings); err != nil {
		return err
	}
	c.YamlSettings = settings
	log.Printf("Parsed settings from %v", path)
	return nil
}

func (c *Config) getEnvs() error {
	if err := env.Parse(c); err != nil {
		return err
	}
	log.Println("Parsed environment variables")
	return nil
}
