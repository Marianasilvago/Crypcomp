package fetcher

import (
	"context"
	"fmt"
	"log"
	"start/crypcomp/client"
	"start/crypcomp/config"
	"start/crypcomp/models"
	"sync/atomic"
	"time"
)

const fetchFrequence = time.Second * 5

type Storage interface {
	CreateCurr(ctx context.Context, curr models.Currency, display models.CurrencyDisplay, batchID int64) error
	GetLatestBatch(ctx context.Context) (int64, error)
}

type Fetch struct {
	httpClient *client.CryptoCompareClient
	storage    Storage
	cfg        *config.Config
}

func NewFetch(client *client.CryptoCompareClient, storage Storage, cfg *config.Config) *Fetch {
	return &Fetch{
		httpClient: client,
		storage:    storage,
		cfg:        cfg,
	}
}

func (f *Fetch) Run(ctx context.Context) {
	log.Println("New fetcher were running")
	fetchCtx, cancel := context.WithCancel(ctx)
	defer cancel()
	ticker := time.NewTicker(fetchFrequence)
	for {
		select {
		case <-fetchCtx.Done():
			log.Println("Killed on demand of context")
			return
		case <-ticker.C:
			result, err := f.httpClient.GetMultiPrice(f.cfg.YamlSettings.Currencies.Fsyms, f.cfg.YamlSettings.Currencies.Tsyms)
			if err != nil {
				log.Println(fmt.Errorf("failed to get data from API: %w", err))
			}
			batchID, err := f.storage.GetLatestBatch(fetchCtx)
			if err != nil {
				log.Println(fmt.Errorf("failed to get latest bath ID from DB: %w", err))
			}
			atomic.AddInt64(&batchID, 1)

			for _, r := range result {
				var curr models.Currency
				var display models.CurrencyDisplay

				curr, ok := r["RAW"].(models.Currency)
				if !ok {
					log.Println("failed to cast models.Currency")
					continue
				}
				display, ok = r["DISPLAY"].(models.CurrencyDisplay)
				if !ok {
					log.Println("failed to cast models.CurrencyDisplay")
					continue
				}
				err := f.storage.CreateCurr(fetchCtx, curr, display, batchID)
				if err != nil {
					log.Println(fmt.Errorf("failed to create currency entity on DB: %w", err))
					continue
				}
			}
		}
	}
}
