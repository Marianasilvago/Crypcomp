package main

import (
	_ "github.com/go-sql-driver/mysql"
	"os"
	"os/signal"
	"start/crypcomp/app"
	"syscall"
)

func main() {
	sigChan := make(chan os.Signal, 1)
	a := app.NewApp()
	a.Start()

	signal.Notify(sigChan, os.Interrupt, syscall.SIGTERM, syscall.SIGINT)
	<-sigChan
	a.Stop()

}
