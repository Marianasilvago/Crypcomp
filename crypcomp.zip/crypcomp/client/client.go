package client

import (
	"encoding/json"
	"errors"
	"io/ioutil"
	"log"
	"net/http"
	"net/url"
	"start/crypcomp/models"
	"strings"
	"time"
)

const priceMultiFullURL = "https://min-api.cryptocompare.com/data/pricemultifull"

var ErrRequestFailed = errors.New("request to CryptoCompareClient not success")

type CryptoCompareClient struct {
	http http.Client
}

func NewCryptoCompareClient() *CryptoCompareClient {
	c := http.Client{
		Timeout: time.Second * 5,
	}
	return &CryptoCompareClient{http: c}
}

func (c *CryptoCompareClient) GetMultiPrice(fsyms []string, tsyms []string) ([]map[string]interface{}, error) {
	u, err := url.Parse(priceMultiFullURL)
	if err != nil {
		return nil, err
	}
	q := url.Values{}

	fsymsQuery := strings.Join(fsyms, ",")
	tsymsQuery := strings.Join(tsyms, ",")
	q.Add("fsyms", fsymsQuery)
	q.Add("tsyms", tsymsQuery)
	u.RawQuery = q.Encode()

	req, err := http.NewRequest("GET", u.String(), nil)
	if err != nil {
		return nil, err
	}
	resp, err := c.http.Do(req)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, ErrRequestFailed
	}
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	r, err := c.parseResponse(body, fsyms, tsyms)
	if err != nil {
		return nil, err
	}
	log.Printf("Successfully fetched data from cryptocompare API\nfsyms: %v\ntsyms: %v\n", fsyms, tsyms)
	return r, nil

}

func (c *CryptoCompareClient) parseResponse(body []byte, fsyms []string, tsyms []string) ([]map[string]interface{}, error) {
	var objMap map[string]json.RawMessage
	var rawObj map[string]json.RawMessage
	var displayObj map[string]json.RawMessage
	var pairs []map[string]interface{}

	err := json.Unmarshal(body, &objMap)
	if err != nil {
		return nil, err
	}
	err = json.Unmarshal(objMap["RAW"], &rawObj)
	if err != nil {
		return nil, err
	}
	err = json.Unmarshal(objMap["DISPLAY"], &displayObj)
	if err != nil {
		return nil, err
	}

	for _, fsym := range fsyms {
		var fsymObjRaw map[string]json.RawMessage
		var fsymObjDisplay map[string]json.RawMessage

		err = json.Unmarshal(rawObj[fsym], &fsymObjRaw)
		if err != nil {
			return nil, err
		}
		err = json.Unmarshal(displayObj[fsym], &fsymObjDisplay)
		if err != nil {
			return nil, err
		}

		for _, tsym := range tsyms {
			var currency models.Currency
			var display models.CurrencyDisplay
			pair := make(map[string]interface{})

			err = json.Unmarshal(fsymObjRaw[tsym], &currency)
			if err != nil {
				return nil, err
			}
			err = json.Unmarshal(fsymObjDisplay[tsym], &display)
			if err != nil {
				return nil, err
			}

			currency.CurrFrom = fsym
			currency.CurrTo = tsym
			pair["RAW"] = currency
			pair["DISPLAY"] = display
			pairs = append(pairs, pair)
		}
	}
	return pairs, nil
}
